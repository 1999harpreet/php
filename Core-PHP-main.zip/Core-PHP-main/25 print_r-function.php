<?php
$name = array("yogesh", "neeraj", "deepak", "pratham", "manish");
$fees = array("yogesh" => 500, "manish" => 400, "shivansh" => 300, "pratham" => 200, "anmol" => 100);
?>
<pre> <?php print_r($fees); ?> </pre>
<pre> <?php print_r($name); ?> </pre>