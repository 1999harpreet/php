<?php

function local_var(){
    $a = 20;
    echo "the variable used in function is a LOCAL VARIABLE \$a is $a";
}

local_var();