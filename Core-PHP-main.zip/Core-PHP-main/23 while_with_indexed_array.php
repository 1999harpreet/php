<?php

$name = array("yogesh", "neeraj", "deepak", "pratham", "manish");

$i = 0;
while($i < count($name)){
    echo "array value is {$name[$i]} <br>";
    $i++;
}