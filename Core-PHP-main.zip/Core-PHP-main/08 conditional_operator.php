<?php

$num = 25;

$result = ($num < 100) ? "$num is odd number" : "$num is even number";
echo $result;

?>