<?php

$name = "Yogesh Pandey";

if (isset($name))
{
    echo "Data Set";
}
else
{
    echo "Data Not Set";
}