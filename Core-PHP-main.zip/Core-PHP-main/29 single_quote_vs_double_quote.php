<?php

$num = 123;
echo "$num <br>";
echo '$num' . "<br>";

echo "Hello 'Yogesh' $num<br>" ;
echo 'Hello "Yogesh" $num <br>';

echo "Yogesh \"Pandey\" $num <br>";
echo 'Yogesh \'Pandey\' $num <br>';
echo "\\";