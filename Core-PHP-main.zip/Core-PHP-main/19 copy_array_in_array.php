<?php

$name = array("yogesh", "neeraj", "deepak", "pratham", "manish");
echo "name of second array is : " . $name[1]. "<br>";

$student_name = $name;

echo "student name of second array is : " . $student_name[1];
