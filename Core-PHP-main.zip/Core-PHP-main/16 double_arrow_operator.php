<?php

$name = array(1=>"yogesh",3=>"neeraj",5=>"deepak",7=>"pratham",9=>"manish");
echo "Value of second array is : " . $name[3];