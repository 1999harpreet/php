<?php

// Single line cmment
# This is also a Single line comment

echo "Hello Yogesh Pandey"; // Single line Comment

/**
 * this is 
 * multi-line 
 * comment
 */