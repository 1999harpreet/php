<?php

if (TRUE) :
    function display()
    {
        echo "hello... condition function";
    }
endif;

// Calling Function With Condition

if (TRUE) :
    display();
endif;
