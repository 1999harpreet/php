<?php

$name = "Yogesh";
echo "{$name}Pandey" . "<br>";
echo "My name is $name Pandey <br>";

$num = 10;
echo 'this number is $num' . "<br>";
echo "this number is $num \$value";

?>
