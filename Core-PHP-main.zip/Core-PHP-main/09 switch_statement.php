<?php

$value = "o";

switch ($value):
    case "A":
        echo "Given character A is vowel";
        break;
    case "E":
        echo "Given character E is vowel";
        break;
    case "I":
        echo "Given character I is vowel";
        break;
    case "O":
        echo "Given character O is vowel";
        break;
    case "U":
        echo "Given character U is vowel";
        break;
    case "a":
        echo "Given character (a) is vowel";
        break;
    case "e":
        echo "Given character (e) is vowel";
        break;
    case "i":
        echo "Given character (i) is vowel";
        break;
    case "o":
        echo "Given character (o) is vowel";
        break;
    case "u":
        echo "Given character (u) is vowel";
        break;
    default:
        echo "Given character is consonant";

endswitch;

?>