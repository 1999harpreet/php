<?php

    define("PI", 3.14);
    echo PI . "<br>";
    echo "PI value is : " . PI ;

?>