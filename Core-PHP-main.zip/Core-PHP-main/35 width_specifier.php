<?php

$a = "Hello";
$b = "Yogesh Pandey";
$c = 9888066739;
$d = "hey";
?><pre><?php
printf ("%15s <br>", $a);
printf ("%15s <br>", $b);
printf ("%15d <br>", $c);
printf ("%-15s <br>", $d);
?></pre>