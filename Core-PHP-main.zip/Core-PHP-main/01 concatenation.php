<?php

    // Code #1 :

    $num1 = 20;
    $num2 = 30;
    $total = $num1 + $num2;

    echo $num1 . " + " . $num2 . " = " . $total;
    echo "<br>";
    echo ($num1 + $num2) . "<br>";


    // Code #2 :

    $a = "Hello";
    $b = "YogeshPandey";
    $c = $a . $b;

    echo $c;
    echo "<br>";

    // Code #3 :
    $x = "Yogesh";
    $y = "Pandey";

    echo $x . " " . $y;
    echo "<br>";

    // Code #4 :
    $z = 'yogesh';
    $z.= " pandey";
    echo $z;

?>
