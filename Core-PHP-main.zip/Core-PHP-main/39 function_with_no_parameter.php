<?php

function data(){
    $name = "Yogesh";
    $age = 25;
    echo "my name is $name and i'm $age year old <br>";

}

echo "first line <br>";
echo "second line <br>";

data();

echo "third line <br>";
echo "fourth line <br>";