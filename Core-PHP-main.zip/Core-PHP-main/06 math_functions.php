<?php

echo sqrt(4);

?>