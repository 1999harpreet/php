<?php

function data($first_name, $last_name){
    echo "full name : $first_name $last_name <br>";
}

data("Yogesh","Pandey");
data("Manish","Pandey");