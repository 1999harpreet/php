<?php
$info = <<<HEREDOC
<b>this is first line.</b><br>
<u>this is "<b>second</b>" line.</u><br>
<i>this is third line</i>.
HEREDOC;

echo $info;

?>