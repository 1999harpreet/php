<?php

$a = "Yogesh";
$b = 25;

printf("hello... my name is %s and im %d year old.", $a, $b );

printf("%%d <br>");
printf("decimal intiger %%d = %d<br>", $b);
printf("float or double (locale aware) %%f = %f <br>", $b);
printf("string %%s = %s <br>", $a);
printf("binary %%b = %b <br>", $b);
printf("scientific notation %%e = %e<br>", $b);
printf("float or double (non-locale aware) %%F = %F<br>", $b);