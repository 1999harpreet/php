<?php

function add($a, $b){
    $sum = $a+$b;
    return($sum ."<br>");
}

echo add(12, 55);

$totle = add(5,8);
echo $totle;