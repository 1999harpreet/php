<?php

$fees = array("yogesh" => 500, "manish" => 400, "shivansh" => 300, "pratham" => 200, "anmol" => 100);

foreach ($fees as $key => $money) {
    echo $key . " fees is " . $money . "<br>";
}