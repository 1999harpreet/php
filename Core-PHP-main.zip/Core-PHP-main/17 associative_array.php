<?php

// $fees["yogesh"] = 500;
// $fees["manish"] = 400;
// $fees["shivansh"] = 300;
// $fees["pratham"] = 200;
// $fees["anmol"] = 100;

// echo "Anmol Fees : " . $fees["anmol"];

$fees = array("yogesh" => 500, "manish" => 400, "shivansh" => 300, "pratham" => 200, "anmol" => 100);

echo "Manish Fees : {$fees["manish"]} <br>";


