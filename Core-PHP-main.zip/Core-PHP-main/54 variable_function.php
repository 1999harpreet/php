<?php

function one(){
    echo "Function One";
}
function two(){
    echo "Function Two";
}
function three(){
    echo "Function Three";
}

$f_variable = "one";    // assigning function name to a variable
$f_variable();          // calling , have to write $ sign
