<?php

$name = array("yogesh", "neeraj", "deepak", "pratham", "manish");
// echo "Value of second array is : " . $name[1];

foreach ($name as $key => $value) {
    echo "Value of array $key is : $value <br>";
}
