<?php

$a = -55;
$b = +44;

printf("%d <br>", $a);
printf("%d <br>", $b);
printf("%+d", $b);    
