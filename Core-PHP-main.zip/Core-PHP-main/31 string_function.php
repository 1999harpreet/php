<?php

$ch = "Hello Yogesh";

echo strtolower($ch) . "<br>";
echo strtoupper($ch) . "<br>";
echo strlen($ch) . "<br>";